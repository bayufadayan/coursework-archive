import React, { useState, useCallback } from 'react';
import { Text, SafeAreaView, StyleSheet, TextInput, TouchableOpacity, View, Linking, Alert } from 'react-native';
import Toast from 'react-native-toast-message';
import { Card } from 'react-native-paper';

const supportedURL = 'https://94eb-125-166-115-43.ngrok-free.app/'; 

// Komponen untuk membuka URL dengan pengecekan
const OpenURLButton = ({ url, children }) => {
  const handlePress = useCallback(async () => {
    const supported = await Linking.canOpenURL(url);
    
    if (supported) {
      await Linking.openURL(url); 
    } else {
      Alert.alert(`Tidak tahu cara membuka URL ini: ${url}`); 
    }
  }, [url]);

  return (
    <TouchableOpacity style={styles.button} onPress={handlePress}>
      <Text style={styles.buttonText}>{children}</Text>
    </TouchableOpacity>
  );
};

export default function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Validasi untuk field kosong
    if (!username || !password) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Silahkan isi semua field yang kosong',
      });
      return;
    }

    // Validasi username dan password
    if (username === 'admin' && password === '$b3laj4r') {
      Toast.show({
        type: 'success',
        text1: 'Login Berhasil',
        text2: 'Anda akan dialihkan...',
      });

      // Delay 1.5 detik untuk menampilkan toast sukses sebelum redirect
      setTimeout(() => {
        Linking.canOpenURL(supportedURL).then((supported) => {
          if (supported) {
            Linking.openURL(supportedURL); 
          } else {
            Alert.alert(`Tidak tahu cara membuka URL ini: ${supportedURL}`);
          }
        });
      }, 1500);
    } else {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Username atau password salah!',
      });
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <Card style={styles.card}>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
          />
        </View>

        {/* Button untuk login dan redirect */}
        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>Login</Text>
        </TouchableOpacity>
      </Card>
      <Toast />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  card: {
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    height: 48,
    borderColor: '#ced4da',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    marginBottom: 12,
    fontSize: 16,
    backgroundColor: '#f8f9fa',
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
