import React, { useState } from "react";
import { Toaster, toast } from "react-hot-toast";
import "./Login.css";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    if (!username || !password) {
      toast.error("Silahkan isi semua field yang kosong");
      return;
    }

    if (username === "admin" && password === "$b3laj4r") {
      setError("");
      toast.success("Login berhasil!");
      setTimeout(() => {
        window.location.href = "https://94eb-125-166-115-43.ngrok-free.app/";
      }, 1500);
    } else {
      setError("Username atau password salah!");
      toast.error("Username atau password salah!");
    }
  };

  return (
    <div className="login-container">
      <Toaster position="top-right" reverseOrder={false} />{" "}
      {/* Komponen Toaster untuk menampilkan notifikasi */}
      <div className="login-box">
        <h2 className="login-title">Login</h2>
        {error && <div className="login-error">{error}</div>}
        <form onSubmit={handleLogin}>
          <div className="login-input-group">
            <label htmlFor="username" className="login-label">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="login-input"
              placeholder="Masukkan username"
              required
            />
          </div>
          <div className="login-input-group">
            <label htmlFor="password" className="login-label">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="login-input"
              placeholder="Masukkan password"
              required
            />
          </div>
          <button type="submit" className="login-button">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
